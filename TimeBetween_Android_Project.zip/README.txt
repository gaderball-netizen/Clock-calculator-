TIME BETWEEN - Android App Project

Functionality:
- 24-hour HH:MM time
- Type 0800 and it formats to 08:00
- Calculates elapsed time
- Automatically handles overnight ranges (22:00 -> 06:00 = 8 HR 00 MIN)
- Offline app; no internet permission required
- Fiery clock launcher icon

To build in Android Studio:
1. Open this TimeBetween_Android folder as a project.
2. Allow Gradle/Android SDK components to sync/install.
3. Build > Build APK(s).
4. APK will be under app/build/outputs/apk/debug/app-debug.apk.

This project also contains .github/workflows/build-apk.yml so GitHub Actions
can build the APK automatically when pushed to a GitHub repository.
